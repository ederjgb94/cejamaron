<?php

namespace App\Http\Controllers;

use Spatie\Async\Pool;
use App\Jobs\ProcessPodcast;
use App\Models\Producto;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;

class ProductoController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return Producto::orderBy('created_at', 'desc')->get();
    }


    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $nuevos_productos = $request['nuevos_productos'];

        foreach ($nuevos_productos as  $nuevo_producto) {
            $producto = new Producto();
            $producto->create($nuevo_producto);
            array_push($ids, $producto->id);
        }
        $this->send_firebase_notification();
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Producto  $producto
     * @return \Illuminate\Http\Response
     */
    public function show(Producto $producto)
    {
        return $producto;
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Producto  $producto
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Producto $producto)
    {
        $producto->update($request->all());
        $this->send_firebase_notification();
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Producto  $producto
     * @return \Illuminate\Http\Response
     */
    public function destroy(Producto $producto)
    {
    }

    public function disable(Producto $producto)
    {
        $producto->activo = false;
        $producto->save();
        $this->send_firebase_notification();
    }

    public function activate(Producto $producto)
    {
        $producto->activo = true;
        $producto->save();
        $this->send_firebase_notification();
    }
}
